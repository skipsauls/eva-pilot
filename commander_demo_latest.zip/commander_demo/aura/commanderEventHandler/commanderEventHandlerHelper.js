({
	fireCommanderState : function(cmp, state) {
        cmp.set('v.commanderState', state);
	},
    fireAnalyticsAppCreateEvent: function(cmp, event, autoInstallRequests){
        var event = cmp.getEvent("AnalyticsAppCreate");
        if (event && autoInstallRequests.length > 0){
            event.setParam('autoInstallRequest', autoInstallRequests[0].outputValues);
            event.fire();
        }
    },
    toaster: function(message, type, duration){
        var toastEvent = $A.get("e.force:showToast");
        if (toastEvent){
            toastEvent.setParams({
                message: message,
                duration: duration ? duration : '5000',
                key: 'info_alt',
                type: type,
                mode: 'pester'
            });
            toastEvent.fire();            
        }
        else{
            $A.log('commanderUtilityController: ' + message);
        }        
    },
    handleMultipleResults: function(cmp, columns, results, keyAttribute, selectHandler){
        $A.log('Multiple records returned, displaying in picker.');
        var modalBody, modalOverlay;
        $A.createComponent('c:genericJsonDataGrid', {
            'items': results, 
            'keyAttr': keyAttribute ? keyAttribute : 'Id',
            'cols': columns,
            'onselect': function(selected){
                if (modalOverlay){
                    modalOverlay.close();
                }
                selectHandler(selected);
            }
        }, function(content, status) {
               if (status === "SUCCESS") {
                   modalBody = content;
                   cmp.find('overlayApi').showCustomModal({
                       header: "Results",
                       body: modalBody, 
                       showCloseButton: true,
                       closeCallback: function() {
                       }
                   }).then(function(overlay){
                       modalOverlay = overlay;
                   });
               }                               
           });
    },
    navigateTo: function(cmp, pageReference){
        var navService = cmp.find("navService");
        if (navService){
            navService.generateUrl(pageReference)
                .then($A.getCallback(function(url){
                    $A.log('url:' + url);
                    navService.navigate(pageReference);
                }), $A.getCallback(function(error){
                    $A.log('Record url error:' + error);
                }));
        } else {
            $A.log('Unable to find navigation service.')
        }
    },
    viewSobject: function(cmp, sobject){
        var pageReference = {
            type: 'standard__recordPage',
            attributes: {
                actionName: 'view',
                recordId: sobject.id
            }
        };
        $A.log('Navigating to sobject:' + sobject.name + ", id: " + sobject.id);
		this.navigateTo(cmp, pageReference);
        this.fireCommanderState(cmp, sobject.state);
    },
    viewDashboardWithState: function(cmp, state){
        var pageReference = {
            type: 'standard__navItemPage',
            attributes: {
                apiName: 'Analytics_Dashboard'
            },
            state: state
        };
		this.navigateTo(cmp, pageReference);
    },
    viewDashboard: function(cmp, dashboard){
        $A.log('Navigating to dashboard:' + dashboard.name + ", id: " + dashboard.id);
        this.viewDashboardWithState(cmp, {c__dashboardId: dashboard.id, c__forceRefresh: true});
        this.fireCommanderState(cmp, dashboard.state);
    },
    viewDashboardPage: function(cmp, page){
        $A.log('Navigating to dashboard page:' + page.name + ", id: " + page.id);
        this.viewDashboardWithState(cmp, {c__dashboardId:page.id, c__pageId: page.name});
        this.fireCommanderState(cmp, page.state);
    }
})