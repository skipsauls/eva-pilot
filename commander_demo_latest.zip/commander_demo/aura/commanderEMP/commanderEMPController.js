({
	init: function(cmp, event, helper){
    	var subscribed = cmp.get('v.subscribed');
        console.warn('handleSubscribedChange: ', subscribed);
        if (subscribed === true) {
            helper.subscribe(cmp);
        } else {
            helper.unsubscribe(cmp);
        }
	},
    
    handleSubscribedChange: function(cmp, event, helper) {
    	var subscribed = cmp.get('v.subscribed');
        console.warn('handleSubscribedChange: ', subscribed);
        if (subscribed === true) {
            helper.subscribe(cmp);
        } else {
            helper.unsubscribe(cmp);
        }
	},
    
    subscribe: function(cmp, event, helper) {
        helper.subscribe(cmp);
    },

    unsubscribe: function(cmp, event, helper) {
        helper.unsubscribe(cmp);
    }
})